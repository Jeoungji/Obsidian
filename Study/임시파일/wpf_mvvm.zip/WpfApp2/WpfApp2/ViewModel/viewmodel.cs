﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace WpfApp2.ViewModel
{
    public class ViewModel : INotifyPropertyChanged
    {
        private ObservableCollection<Model.Person> plist = null;
        public ObservableCollection<Model.Person> Plist { get { return plist; } }

        private int selectedIdx;
        public int SelectedIdx { get { return selectedIdx; } set { selectedIdx = value; } }

        private Model.Model model = null;
        public Model.Model Model { get { return model; } 
        set { model = value; onPropertyChanged("Model"); }
        }

        public Command Cmd {  get; set; }
        public Command CmdEdit { get; set; }

        public ViewModel()
        {
            model = new Model.Model();
            Cmd = new Command(Execute_func, CanExecute_func);
            CmdEdit = new Command(Execute_edit, CanExecute_edit);
            plist = new ObservableCollection<Model.Person>();
            plist.Add(new Model.Person(1, "aaa"));
            plist.Add(new Model.Person(2, "bbbb"));
        }
        private void Execute_func(object obj)
        {
            //Model.Res = Model.Num + " / " + Model.Name;
            Plist.Add(new Model.Person(Model.Num, Model.Name));
         
        }

        private bool CanExecute_func(object obj)
        {
            return true;
        }
        private void Execute_edit(object obj)
        {
            MessageBox.Show(SelectedIdx + ""); 
            Plist[SelectedIdx].Name = Model.Name;
            Plist[SelectedIdx].Num = Model.Num;
            //Plist.RemoveAt(SelectedIdx);
        }

        private bool CanExecute_edit(object obj)
        {
            return true;
        }
        public event PropertyChangedEventHandler PropertyChanged;

        protected void onPropertyChanged(string propertyName)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (handler != null) handler(this, new PropertyChangedEventArgs(propertyName));
        }
    }
    
    
}

