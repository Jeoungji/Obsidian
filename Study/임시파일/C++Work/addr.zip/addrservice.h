#ifndef ADDRSERVICE_H_INCLUDED
#define ADDRSERVICE_H_INCLUDED

#include "addr.h"


//service:����Ͻ� ���� ����
class AddrService{
    AddrProcess pr; //���԰���
public:
    //�߰�
    void add(){
        cout<<"����߰�"<<endl;
        cout<<"name:";
        string name;
        cin>>name;
        string tel;
        cout<<"tel:";
        cin>>tel;
        bool flag = pr.addMember(new Member(name, tel));
        if(flag){
            cout<<"���� ó���� "<<endl;
        }else{
            cout<<"�޸� ���� ���� "<<endl;
        }
    }

    //�˻�
    void printMember(){
        cout<<"��ȣ�� �˻�"<<endl;
        cout<<"num:";
        int num;
        cin>>num;
        Member *res = pr.getByIdx(pr.getByNum(num));
        if(res == NULL){
            cout<<"not found"<<endl;
        }else{
            cout<<"num:"<<res->getNum()<<endl;
            cout<<"name:"<<res->getName()<<endl;
            cout<<"tel:"<<res->getTel()<<endl;
        }
    }

    //����
    void editMember(){
        cout<<"����"<<endl;
        cout<<"edit num:";
        int num;
        cin>>num;
        Member *res = pr.getByIdx(pr.getByNum(num));
        if(res == NULL){
            cout<<"not found"<<endl;
        }else{
            string tel;
            cout<<"new tel:";
            cin>>tel;
            res->setTel(tel);
        }
    }

    //����
    void delMember(){
        cout<<"����"<<endl;
        cout<<"del num:";
        int num;
        cin>>num;
        bool flag = pr.delMember(pr.getByNum(num));
        if(flag){
            cout<<"����ó����"<<endl;
        }else{
            cout<<"�������"<<endl;
        }
    }

    //��ü���
    void printAll(){
        for(int i=0;i<pr.getCnt();i++){
            Member *res = pr.getByIdx(i);
            cout<<"num:"<<res->getNum()<<endl;
            cout<<"name:"<<res->getName()<<endl;
            cout<<"tel:"<<res->getTel()<<endl;
        }
    }

};

#endif // ADDRSERVICE_H_INCLUDED
