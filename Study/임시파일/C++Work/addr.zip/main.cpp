#include "menu.h"

int main()
{
    AddrMenu m;
    m.run();
    return 0;
}
