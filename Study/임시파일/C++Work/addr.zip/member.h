#ifndef MEMBER_H_INCLUDED
#define MEMBER_H_INCLUDED
//vo
#include <iostream>
#include <cstring>
using namespace std;

class Member{
    static int cnt;
    int num;  //�ڵ��Ҵ�
    string name;
    string tel;

public:
    Member(){}
    Member(string name, string tel){
        num = ++cnt;
        this->name = name;
        this->tel = tel;
    }
    int getNum(){
        return num;
    }

    string getName(){
        return name;
    }

    string getTel(){
        return tel;
    }

    void setTel(string tel){
        this->tel = tel;
    }


};
int Member::cnt = 0;
#endif // MEMBER_H_INCLUDED
